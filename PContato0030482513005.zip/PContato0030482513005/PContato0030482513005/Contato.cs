﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PContato0030482513005
{
    internal class Contato //Classe interna Contato
    {
        public int Idcontato { get; set; }
        public string Nomecontato { get; set; }
        public string Endcontato { get; set; }
        public int CidadeidCidade { get; set; }
        public string Celcontato { get; set; }
        public string Emailcontato { get; set; }
        public DateTime Dtcadastocontato { get; set; }

        public DataTable Listar()//Criando método tipo DataTable
        {
            SqlDataAdapter daContato;
            DataTable dtContato = new DataTable();

            try
            {
                daContato = new SqlDataAdapter("SELECT * FROM CONTATO ORDER BY NOME_CONTATO",
                    frmPrincipal.conexao);
                daContato.Fill(dtContato);
                daContato.FillSchema(dtContato, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtContato;
        }
        public int Incluir()//inclusao
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("INSERT INTO CONTATO VALUES (@nomecontato, @endcontato, @cidadeidcidade, @celcontato, @emailcontato, @dtcadastrocontato)",
                    frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailconato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.VarChar));

                mycommand.Parameters["@nomecontato"].Value = Nomecontato;
                mycommand.Parameters["@endcontato"].Value = Endcontato;
                mycommand.Parameters["@cidadecontato"].Value = CidadeidCidade;
                mycommand.Parameters["@celcontato"].Value = Celcontato;
                mycommand.Parameters["@emailcontato"].Value = Emailcontato;
                mycommand.Parameters["@dtcadastrocontato"].Value = Dtcadastocontato;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw;
            }

            return retorno;
        }
        
    }
}

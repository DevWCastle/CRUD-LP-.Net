﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482513005
{
    
    public partial class frmPrincipal : Form
    {

        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=Nikolau\\sqlexpress;Initial Catalog=BD;Integrated Security=True");
                conexao.Open();
            }
            catch( SqlException ex)
            {
                MessageBox.Show("Erro de bacno de dados =/"  + ex.Message);
            }
            catch (Exception ex) { 
            
                MessageBox.Show("Outros erros" + ex.Message);
            }
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato FRMC = new frmContato();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }





        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Deseja sair?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) { 
            this.Close();
        }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                Application.OpenForms["frmSobre"].BringToFront();
            }
            else
            {
                frmSobre FRMC = new frmSobre();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }
    }
}

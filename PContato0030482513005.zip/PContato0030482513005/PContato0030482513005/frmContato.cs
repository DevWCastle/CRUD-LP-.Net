﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482513005
{
    public partial class frmContato : Form
    {

        private BindingSource bnContato =  new BindingSource();
        private bool bInclusao = false;

        private DataSet dsContato = new DataSet();
        private DataSet dsCidade = new DataSet();
        public frmContato()
        {
            InitializeComponent();
        }

        private void frmContato_Load(object sender, EventArgs e)
        {
            try
            {
                Contato Con = new Contato();

                dsContato.Tables.Add(Con.Listar());
                bnContato.DataSource = dsContato.Tables["Contato"];

                dgvContato.DataSource = bnContato;
                bnvContato.BindingSource = bnContato;


                txtIdContato.DataBindings.Add("TEXT", bnContato, "id_contato");
                txtNomeContato.DataBindings.Add("TEXT", bnContato, "nome_contato");
                txtEndContato.DataBindings.Add("TEXT", bnContato, "end_contato");
                txtCelContato.DataBindings.Add("TEXT", bnContato, "cel_contato");
                txtEmailContato.DataBindings.Add("TEXT", bnContato, "email_contato");
                dtpDtCadastroContato.DataBindings.Add("TEXT", bnContato, "dtcadastro_contato");


                Cidade Cid = new Cidade();

                dsCidade.Tables.Add(Cid.Listar());

                cbxCidadeContato.DataSource = dsCidade.Tables["Cidade"];

                cbxCidadeContato.ValueMember = "id_cidade";

            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void lblCidadeContato_Click(object sender, EventArgs e)
        {

        }
    }
}
